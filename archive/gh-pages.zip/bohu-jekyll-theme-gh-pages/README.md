# BoHu 

It's a simple jekyll blog theme. 
  
A style of ZhiHu - the best-known website to share knowledge in China.   

In the ZhiHu, you can learn knowledge from all over the world.   

In the BoHu, you can share knowledge to all over the world!

1. **Use paging as 1,2,3,4,5......**   
1. **Searchable for blog.**    
1. **Classification is supported.**   
1. **Good compatibility on mobile devices.**    
1. **Built-in wordart for English and Chinese.**   
1. **Music player.**   
**......**

**Make it yours in under 10 minutes.**  

# Author

[Clark Zhao](http://zhaoyuxiang.cn)


# License

Use MIT License.