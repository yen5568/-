---
layout: post
title: Whats BoHu?
author: CK
date:   2016-04-23
categories: BoHu
permalink: /archivers/Whats-Bohu
---



Welcome to BoHu！

This is my first Jekyll-Theme！

It's a style of ZhiHu. Zhihu is one of the most famous sites in China which to learn each other's knowledge from all over the world. Color and size is strictly in accordance with the ZhiHu. More content will be added in the follow-up!

In the ZhiHu, you can learn knowledge from all over the world. In the BoHu, you can share knowledge to all over the world!
